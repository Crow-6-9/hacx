from __future__ import annotations

import json
from unittest import mock

import numpy as np
import pytest

from app.agents.router import RouterResult
from app.agents.domain import DomainResult
from app.agents.synthesizer import SynthesizerResult
from app.orchestrator import Orchestrator, OrchestratorResult
from app.retrieval.retriever import Retriever, SearchResult

DOMAINS = ["Billing", "Technical", "Cancellation", "General"]


def _make_retriever() -> Retriever:
    metadata = [
        {
            "ticket_id": "T001",
            "subject": "Double billing",
            "description": "Charged twice",
            "resolution": "Refunded duplicate",
            "domain": "Billing",
        },
        {
            "ticket_id": "T002",
            "subject": "Login failure",
            "description": "Can't log in",
            "resolution": "Reset password",
            "domain": "Technical",
        },
        {
            "ticket_id": "T003",
            "subject": "Cancel request",
            "description": "Wants to cancel",
            "resolution": "Processed cancellation",
            "domain": "Cancellation",
        },
    ]
    vectors = np.eye(3, 4, dtype="float32")
    index = {"type": "numpy", "vectors": vectors}
    return Retriever(index, metadata)


def _make_orchestrator() -> Orchestrator:
    return Orchestrator(_make_retriever(), DOMAINS)


def _mock_chat_factory(route_domain: str = "Billing", confidence: float = 0.9) -> mock.MagicMock:
    call_count = {"n": 0}

    def side_effect(system: str, user: str, max_tokens: int = 1024) -> str:
        call_count["n"] += 1
        if call_count["n"] == 1:
            return json.dumps({"domain": route_domain, "confidence": confidence, "reasoning": "test"})
        if call_count["n"] == 2:
            return "Draft: Customer was billed twice. Refund the duplicate. [Ticket #T001]"
        return "Polished reply referencing [Ticket #T001]."

    return mock.MagicMock(side_effect=side_effect)


# ── Integration tests ────────────────────────────────────────────────────────

@pytest.mark.parametrize(
    "message,expected_domain",
    [
        ("I was charged twice on my last invoice", "Billing"),
        ("I cannot log in to my account", "Technical"),
        ("I want to cancel my subscription", "Cancellation"),
    ],
)
def test_orchestrator_happy_path(message: str, expected_domain: str):
    orch = _make_orchestrator()
    mock_fn = _mock_chat_factory(route_domain=expected_domain)
    with mock.patch("app.agents.router.chat", mock_fn), \
         mock.patch("app.agents.domain.chat", mock_fn), \
         mock.patch("app.agents.synthesizer.chat", mock_fn), \
         mock.patch("app.retrieval.retriever.embed", return_value=[[1.0, 0.0, 0.0, 0.0]]):
        result = orch.resolve(message)

    assert isinstance(result, OrchestratorResult)
    assert result.domain == expected_domain
    assert isinstance(result.reply, str)
    assert len(result.reply) > 0
    assert result.confidence > 0
    assert isinstance(result.similar_tickets, list)
    assert isinstance(result.trace, list)
    assert len(result.trace) == 4


def test_orchestrator_low_confidence_escalation():
    orch = _make_orchestrator()
    mock_fn = _mock_chat_factory(route_domain="General", confidence=0.2)

    def synth_side(*args, **kwargs):
        return "I don't have a close historical match for this issue — escalating to a human agent."

    with mock.patch("app.agents.router.chat", mock_fn), \
         mock.patch("app.agents.domain.chat", mock_fn), \
         mock.patch("app.agents.synthesizer.chat", side_effect=synth_side), \
         mock.patch("app.retrieval.retriever.embed", return_value=[[0.0, 0.0, 0.0, 1.0]]):
        result = orch.resolve("some completely unrelated question")

    assert "escalat" in result.reply.lower()


def test_orchestrator_conversation_history_passed():
    orch = _make_orchestrator()
    history = [
        {"role": "user", "content": "My bill is wrong"},
        {"role": "assistant", "content": "I can help with billing issues."},
    ]
    captured_calls = []

    def capture_chat(system, user, max_tokens=1024):
        captured_calls.append({"system": system, "user": user})
        if len(captured_calls) == 1:
            return json.dumps({"domain": "Billing", "confidence": 0.85, "reasoning": "billing"})
        if len(captured_calls) == 2:
            return "Draft reply with history context"
        return "Final reply [Ticket #T001]"

    with mock.patch("app.agents.router.chat", side_effect=capture_chat), \
         mock.patch("app.agents.domain.chat", side_effect=capture_chat), \
         mock.patch("app.agents.synthesizer.chat", side_effect=capture_chat), \
         mock.patch("app.retrieval.retriever.embed", return_value=[[1.0, 0.0, 0.0, 0.0]]):
        result = orch.resolve("I was still charged incorrectly", history)

    assert isinstance(result, OrchestratorResult)
