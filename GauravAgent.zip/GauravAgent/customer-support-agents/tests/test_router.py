from __future__ import annotations

import json
from unittest import mock

import pytest

from app.agents.router import RouterAgent, RouterResult


DOMAINS = ["Billing", "Technical", "Cancellation", "Refund", "Product Inquiry", "General"]


def _make_router() -> RouterAgent:
    return RouterAgent(DOMAINS)


def test_router_parses_valid_json():
    router = _make_router()
    mock_response = json.dumps(
        {"domain": "Billing", "confidence": 0.95, "reasoning": "Mentions invoice and charge."}
    )
    with mock.patch("app.agents.router.chat", return_value=mock_response):
        result = router.run("I was charged twice on my invoice")
    assert result.domain == "Billing"
    assert result.confidence == pytest.approx(0.95)
    assert "invoice" in result.reasoning.lower() or result.reasoning


def test_router_normalizes_domain_case():
    router = _make_router()
    mock_response = json.dumps(
        {"domain": "billing", "confidence": 0.9, "reasoning": "billing issue"}
    )
    with mock.patch("app.agents.router.chat", return_value=mock_response):
        result = router.run("billing problem")
    assert result.domain == "Billing"


def test_router_falls_back_on_unknown_domain():
    router = _make_router()
    mock_response = json.dumps(
        {"domain": "UnknownDomain", "confidence": 0.5, "reasoning": "unclear"}
    )
    with mock.patch("app.agents.router.chat", return_value=mock_response):
        result = router.run("random message")
    assert result.domain == "General"


def test_router_falls_back_on_parse_error():
    router = _make_router()
    with mock.patch("app.agents.router.chat", return_value="not valid json at all"):
        result = router.run("some message")
    assert result.domain == "General"
    assert result.confidence <= 0.5


def test_router_strips_markdown_code_fences():
    router = _make_router()
    mock_response = "```json\n" + json.dumps({"domain": "Technical", "confidence": 0.88, "reasoning": "tech issue"}) + "\n```"
    with mock.patch("app.agents.router.chat", return_value=mock_response):
        result = router.run("my computer won't boot")
    assert result.domain == "Technical"
