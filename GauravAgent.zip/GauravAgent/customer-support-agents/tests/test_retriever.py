from __future__ import annotations

import numpy as np
import pytest

from app.retrieval.retriever import Retriever, SearchResult


def _make_retriever() -> Retriever:
    metadata = [
        {
            "ticket_id": "T001",
            "subject": "Billing error on invoice",
            "description": "Customer was charged twice",
            "resolution": "Refunded the duplicate charge",
            "domain": "Billing",
        },
        {
            "ticket_id": "T002",
            "subject": "Cannot login to account",
            "description": "Password reset not working",
            "resolution": "Reset password via admin panel",
            "domain": "Technical",
        },
        {
            "ticket_id": "T003",
            "subject": "Request to cancel subscription",
            "description": "Customer wants to cancel",
            "resolution": "Processed cancellation and sent confirmation",
            "domain": "Cancellation",
        },
    ]
    dim = 4
    vectors = np.array(
        [
            [1.0, 0.0, 0.0, 0.0],
            [0.0, 1.0, 0.0, 0.0],
            [0.0, 0.0, 1.0, 0.0],
        ],
        dtype="float32",
    )
    index = {"type": "numpy", "vectors": vectors}
    return Retriever(index, metadata)


def test_search_returns_results():
    retriever = _make_retriever()
    # Query closest to first vector
    import unittest.mock as mock

    with mock.patch("app.retrieval.retriever.embed", return_value=[[1.0, 0.0, 0.0, 0.0]]):
        results = retriever.search("billing issue", k=2)
    assert len(results) == 2
    assert results[0].ticket_id == "T001"


def test_search_domain_filter():
    retriever = _make_retriever()
    import unittest.mock as mock

    with mock.patch("app.retrieval.retriever.embed", return_value=[[1.0, 0.0, 0.0, 0.0]]):
        results = retriever.search("login problem", domain="Technical", k=3)
    assert all(r.domain == "Technical" for r in results)
    assert results[0].ticket_id == "T002"


def test_search_unknown_domain_returns_empty():
    retriever = _make_retriever()
    import unittest.mock as mock

    with mock.patch("app.retrieval.retriever.embed", return_value=[[1.0, 0.0, 0.0, 0.0]]):
        results = retriever.search("anything", domain="NonExistentDomain", k=3)
    assert results == []


def test_search_result_has_expected_fields():
    retriever = _make_retriever()
    import unittest.mock as mock

    with mock.patch("app.retrieval.retriever.embed", return_value=[[1.0, 0.0, 0.0, 0.0]]):
        results = retriever.search("billing", k=1)
    assert len(results) == 1
    r = results[0]
    assert isinstance(r, SearchResult)
    assert r.ticket_id
    assert r.subject
    assert r.resolution
    assert isinstance(r.score, float)
