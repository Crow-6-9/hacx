# Running Locally

## Prerequisites

- Python 3.11 or later
- An Azure OpenAI resource (via Azure AI Foundry) with:
  - A **chat model** deployment (e.g. `gpt-4o`)
  - An **embeddings model** deployment (e.g. `text-embedding-3-small`)

---

## 1. Clone and Enter the Project

```bash
git clone <repo-url>
cd customer-support-agents
```

## 2. Create and Activate a Virtual Environment

```bash
python -m venv .venv

# Windows
.venv\Scripts\activate

# macOS / Linux
source .venv/bin/activate
```

## 3. Install Dependencies

```bash
pip install -r requirements.txt
```

## 4. Configure Environment Variables

```bash
cp .env.example .env
```

Open `.env` and fill in the four required values:

| Variable | Where to find it in Azure AI Foundry |
|----------|--------------------------------------|
| `AZURE_OPENAI_ENDPOINT` | **Settings → Keys and Endpoints** — copy the Endpoint URL (must end in `/openai/v1/`) |
| `AZURE_OPENAI_API_KEY` | **Settings → Keys and Endpoints** — copy Key 1 |
| `AZURE_OPENAI_MODEL` | **Deployments** — the name you gave your chat model deployment (e.g. `gpt-4o`) |
| `AZURE_OPENAI_EMBEDDING_MODEL` | **Deployments** — the name you gave your embeddings deployment (e.g. `text-embedding-3-small`) |

## 5. Add the CSV

Place your ticket data file at:

```
data/customer_support_tickets.csv
```

The app introspects the schema automatically. It needs at minimum columns for: ticket ID, subject, description, resolution, and ticket type.

## 6. Build the Vector Index (One-Time)

```bash
python -m app.retrieval.indexer
```

This embeds all resolved tickets and saves `data/index.faiss` + `data/metadata.pkl`. It rebuilds automatically if the CSV is newer than the index.

## 7. Run the CLI Chatbot

```bash
python -m cli.chat
```

**CLI Commands:**
- `/domain` — show which agent handled the last turn
- `/similar` — show the top-k similar past tickets
- `/reset` — clear conversation history
- `/quit` — exit

## 8. Run the Web UI

```bash
uvicorn web.app:app --reload
```

Open [http://localhost:8000](http://localhost:8000) in your browser.

- The chat panel sends messages to `POST /chat`
- Expand the "similar past tickets" panel below each reply to see retrieval results

## 9. Run Tests

```bash
pytest -q
```

All tests use mocked LLM calls — no Azure credits consumed.

---

## Troubleshooting

### `KeyError: 'AZURE_OPENAI_API_KEY'`
Your `.env` file is missing or not loaded. Make sure the file exists in the project root and contains a non-empty `AZURE_OPENAI_API_KEY=...` line.

### HTTP 401 Unauthorized
The API key is wrong or the endpoint URL is incorrect. Double-check both in the Azure AI Foundry portal under **Settings → Keys and Endpoints**.

### Empty retrieval results
- Confirm `data/customer_support_tickets.csv` exists and has a `Resolution` column with non-empty values.
- Delete `data/index.faiss` and `data/metadata.pkl` and rebuild: `python -m app.retrieval.indexer`

### Embedding quota errors / `429 Too Many Requests`
Your embeddings deployment has hit its TPM (tokens per minute) limit. Either:
- Wait and retry — the indexer processes in 100-ticket batches
- Increase the quota in Azure AI Foundry: **Deployments → your embeddings model → Edit → Tokens per Minute**

### `ModuleNotFoundError: No module named 'faiss'`
Run `pip install faiss-cpu`. On Apple Silicon, you may need `pip install faiss-cpu --no-binary faiss-cpu`.

### TF-IDF fallback mode
If the embeddings endpoint is unavailable, the indexer automatically falls back to TF-IDF (scikit-learn). Retrieval quality is lower but the CLI still works for local development. You will see a warning: `embedding_failed_falling_back_to_tfidf`.
