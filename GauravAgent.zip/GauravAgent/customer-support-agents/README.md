# Customer Support Resolution Agent

A production-ready multi-agent system that routes incoming support tickets to domain-specialized agents, performs semantic similarity search against historical resolutions, and generates grounded responses using Azure OpenAI.

## Architecture

```
User message
    │
    ▼
RouterAgent ──── classifies domain (Billing, Technical, etc.)
    │
    ▼
RetrievalAgent ── semantic search over resolved tickets (FAISS + Azure OpenAI embeddings)
    │
    ▼
DomainAgent ──── grounded resolution draft using top-k similar past tickets
    │
    ▼
SynthesizerAgent ── formats final reply with citations, escalation if needed
    │
    ▼
Structured response: {reply, domain, similar_tickets, confidence, trace}
```

## Interfaces

| Interface | Command |
|-----------|---------|
| CLI chatbot | `python -m cli.chat` |
| Web UI | `uvicorn web.app:app --reload` → http://localhost:8000 |
| HTTP API | `POST /chat` with `{message, history}` |

## Quick Start

See [RUN_LOCAL.md](RUN_LOCAL.md) for full setup instructions.

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # fill in AZURE_OPENAI_* vars
python -m app.retrieval.indexer
python -m cli.chat
```

## Project Structure

```
app/
  llm/client.py          # Single LLM/embedding client (all agents use this)
  agents/
    router.py            # Classifies domain via LLM
    domain.py            # Grounded resolution per domain
    synthesizer.py       # Formats final reply, enforces citations
  retrieval/
    indexer.py           # Builds/loads FAISS index from CSV
    retriever.py         # Semantic search with domain filtering
  prompts/               # Jinja2 templates
  orchestrator.py        # Pipeline: route → retrieve → resolve → synthesize
cli/chat.py              # Rich terminal chatbot
web/app.py               # FastAPI + single-page HTML chat UI
tests/                   # Pytest tests (mocked LLM, no Azure credits)
deploy/
  Dockerfile             # Multi-stage Python 3.11-slim
  azure-foundry-guide.md # Full Azure deployment walkthrough
```

## Key Design Decisions

- **Single LLM client** (`app/llm/client.py`) — all agents call `chat()` or `embed()`, no scattered `OpenAI()` instances
- **TF-IDF fallback** — if Azure embeddings fail, indexer falls back to scikit-learn TF-IDF so local dev still works
- **Citation enforcement** — synthesizer includes `[Ticket #ID]` references when similarity ≥ threshold; escalates when no match found
- **Schema-agnostic CSV loading** — adapter maps column variants automatically; no hardcoded column names
- **Conversation memory** — last 6 turns passed into domain agent prompt
