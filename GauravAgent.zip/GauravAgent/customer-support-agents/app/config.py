from __future__ import annotations

import os
from pathlib import Path

BASE_DIR = Path(__file__).parent.parent
DATA_DIR = BASE_DIR / "data"
PROMPTS_DIR = Path(__file__).parent / "prompts"

FAISS_INDEX_PATH = DATA_DIR / "index.faiss"
METADATA_PATH = DATA_DIR / "metadata.pkl"
CSV_PATH = DATA_DIR / "customer_support_tickets.csv"

SIMILARITY_THRESHOLD: float = float(os.getenv("SIMILARITY_THRESHOLD", "0.6"))
TOP_K: int = int(os.getenv("TOP_K", "5"))
HISTORY_TURNS: int = 6

# Remote CSV source — set to an Azure Blob URL with SAS token for cloud deployment
DATA_SOURCE_URL: str | None = os.getenv("DATA_SOURCE_URL")
