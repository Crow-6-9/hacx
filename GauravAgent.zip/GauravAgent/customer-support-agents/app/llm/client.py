from __future__ import annotations

import os

import structlog
from openai import OpenAI

log = structlog.get_logger()

ENDPOINT = "https://<your-foundry-endpoint>/openai/v1/"


def get_client() -> OpenAI:
    return OpenAI(
        base_url=os.getenv("AZURE_OPENAI_ENDPOINT", ENDPOINT),
        api_key=os.environ["AZURE_OPENAI_API_KEY"],
    )


def get_model() -> str:
    return os.getenv("AZURE_OPENAI_MODEL", "gpt-4o")


def get_embedding_model() -> str:
    return os.getenv("AZURE_OPENAI_EMBEDDING_MODEL", "text-embedding-3-small")


def chat(system: str, user: str, max_tokens: int = 1024) -> str:
    client = get_client()
    response = client.chat.completions.create(
        model=get_model(),
        max_completion_tokens=max_tokens,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        temperature=0,
    )
    content = response.choices[0].message.content
    log.debug(
        "llm_chat",
        model=get_model(),
        prompt_tokens=response.usage.prompt_tokens,
        completion_tokens=response.usage.completion_tokens,
    )
    return content


def embed(texts: list[str]) -> list[list[float]]:
    client = get_client()
    response = client.embeddings.create(
        model=get_embedding_model(),
        input=texts,
    )
    return [item.embedding for item in response.data]
