from __future__ import annotations

import json
import re
from dataclasses import dataclass

import structlog

from app.config import PROMPTS_DIR
from app.llm.client import chat

log = structlog.get_logger()


@dataclass
class RouterResult:
    domain: str
    confidence: float
    reasoning: str


class RouterAgent:
    def __init__(self, domains: list[str]) -> None:
        self._domains = domains
        self._domains_lower: dict[str, str] = {d.lower(): d for d in domains}
        self._system = self._build_system()

    def _build_system(self) -> str:
        from jinja2 import Template

        template = Template((PROMPTS_DIR / "router.j2").read_text())
        return template.render(domains=self._domains)

    def run(self, user_message: str) -> RouterResult:
        raw = chat(self._system, user_message, max_tokens=256)
        result = self._parse(raw)
        log.info("router_decision", domain=result.domain, confidence=result.confidence)
        return result

    def _parse(self, raw: str) -> RouterResult:
        try:
            text = re.sub(r"```[a-z]*\n?", "", raw).strip()
            # Handle trailing ``` if present
            text = text.rstrip("`").strip()
            data = json.loads(text)
            domain_raw = data.get("domain", "General")
            domain = self._domains_lower.get(domain_raw.lower(), "General")
            confidence = float(data.get("confidence", 0.5))
            reasoning = data.get("reasoning", "")
            return RouterResult(domain=domain, confidence=confidence, reasoning=reasoning)
        except Exception as exc:
            log.warning("router_parse_failed", error=str(exc), raw=raw[:200])
            return RouterResult(
                domain="General",
                confidence=0.3,
                reasoning="Parse error; defaulting to General.",
            )
