from __future__ import annotations

from dataclasses import dataclass, field

import structlog
from jinja2 import Template

from app.config import HISTORY_TURNS, PROMPTS_DIR
from app.llm.client import chat
from app.retrieval.retriever import SearchResult

log = structlog.get_logger()


@dataclass
class DomainResult:
    draft: str
    cited_ticket_ids: list[str] = field(default_factory=list)


class DomainAgent:
    def __init__(self, domain: str) -> None:
        self.domain = domain
        self._template = Template((PROMPTS_DIR / "domain_resolution.j2").read_text())

    def run(
        self,
        user_message: str,
        similar_tickets: list[SearchResult],
        history: list[dict] | None = None,
    ) -> DomainResult:
        history = history or []
        history_slice = history[-(HISTORY_TURNS * 2):]

        history_text = ""
        if history_slice:
            lines = [
                f"{msg.get('role', 'user').capitalize()}: {msg.get('content', '')}"
                for msg in history_slice
            ]
            history_text = "\n".join(lines)

        ticket_dicts = [
            {
                "ticket_id": t.ticket_id,
                "subject": t.subject,
                "description": t.description,
                "resolution": t.resolution,
                "score": t.score,
            }
            for t in similar_tickets
        ]

        prompt = self._template.render(
            domain=self.domain,
            similar_tickets=ticket_dicts,
            user_message=user_message,
            conversation_history=history_text,
        )

        draft = chat(
            system=f"You are a senior customer support specialist for the {self.domain} domain.",
            user=prompt,
            max_tokens=1024,
        )

        cited_ids = [t.ticket_id for t in similar_tickets]
        log.info("domain_agent_done", domain=self.domain, cited_tickets=len(cited_ids))
        return DomainResult(draft=draft, cited_ticket_ids=cited_ids)
