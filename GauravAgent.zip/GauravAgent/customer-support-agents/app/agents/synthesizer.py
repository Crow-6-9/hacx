from __future__ import annotations

import re
from dataclasses import dataclass

import structlog

from app.config import SIMILARITY_THRESHOLD
from app.llm.client import chat
from app.retrieval.retriever import SearchResult

log = structlog.get_logger()

_SYSTEM = """You are a customer support quality assurance specialist.
Your job is to take a draft resolution and format it into a clean, professional response.

Structure the reply in this exact order:
1. Greeting (one warm sentence)
2. Diagnosis (one sentence summarizing the issue)
3. Resolution Steps (numbered list, grounded in past resolutions)
4. Escalation Path (only if confidence is low or no historical match exists)
5. References to similar past tickets (format: [Ticket #ID]) — include at least one if available above threshold

Keep the tone professional, empathetic, and concise."""


@dataclass
class SynthesizerResult:
    reply: str
    has_citations: bool


class SynthesizerAgent:
    def run(
        self,
        draft: str,
        similar_tickets: list[SearchResult],
        confidence: float,
        user_message: str,
    ) -> SynthesizerResult:
        above_threshold = [t for t in similar_tickets if t.score >= SIMILARITY_THRESHOLD]

        escalation_note = ""
        if not above_threshold:
            escalation_note = (
                "\n\nIMPORTANT: No close historical match found (all similarity scores below "
                f"{SIMILARITY_THRESHOLD}). You MUST include this exact sentence: "
                "'I don't have a close historical match for this issue — escalating to a human agent.'"
            )

        user_prompt = f"""Draft resolution to polish:
{draft}

Customer's original message:
{user_message}

Confidence level: {confidence:.2f}{escalation_note}

Please format this into a professional customer support response following the required structure."""

        reply = chat(_SYSTEM, user_prompt, max_tokens=1024)
        has_citations = bool(re.search(r"\[Ticket\s*#", reply, re.IGNORECASE))

        log.info(
            "synthesizer_done",
            has_citations=has_citations,
            above_threshold=len(above_threshold),
        )
        return SynthesizerResult(reply=reply, has_citations=has_citations)
