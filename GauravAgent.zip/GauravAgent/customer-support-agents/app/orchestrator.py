from __future__ import annotations

import time
from dataclasses import dataclass, field

import structlog

from app.agents.domain import DomainAgent
from app.agents.router import RouterAgent
from app.agents.synthesizer import SynthesizerAgent
from app.retrieval.retriever import Retriever

log = structlog.get_logger()


@dataclass
class OrchestratorResult:
    reply: str
    domain: str
    similar_tickets: list[dict]
    confidence: float
    trace: list[dict] = field(default_factory=list)


class Orchestrator:
    def __init__(self, retriever: Retriever, domains: list[str]) -> None:
        self._retriever = retriever
        self._router = RouterAgent(domains)
        self._domain_agents: dict[str, DomainAgent] = {d: DomainAgent(d) for d in domains}
        self._synthesizer = SynthesizerAgent()

        if "General" not in self._domain_agents:
            self._domain_agents["General"] = DomainAgent("General")

    def resolve(
        self,
        user_message: str,
        conversation_history: list[dict] | None = None,
    ) -> OrchestratorResult:
        history = conversation_history or []
        trace: list[dict] = []
        t0 = time.perf_counter()

        # Step 1: Route
        route = self._router.run(user_message)
        trace.append(
            {
                "step": "router",
                "domain": route.domain,
                "confidence": route.confidence,
                "reasoning": route.reasoning,
                "latency_ms": int((time.perf_counter() - t0) * 1000),
            }
        )

        # Step 2: Retrieve
        t1 = time.perf_counter()
        similar = self._retriever.search(user_message, domain=route.domain, k=5)
        trace.append(
            {
                "step": "retrieval",
                "domain": route.domain,
                "found": len(similar),
                "latency_ms": int((time.perf_counter() - t1) * 1000),
            }
        )

        # Step 3: Domain agent
        t2 = time.perf_counter()
        agent = self._domain_agents.get(route.domain) or self._domain_agents["General"]
        domain_result = agent.run(user_message, similar, history)
        trace.append(
            {
                "step": "domain_agent",
                "domain": route.domain,
                "latency_ms": int((time.perf_counter() - t2) * 1000),
            }
        )

        # Step 4: Synthesize
        t3 = time.perf_counter()
        synth = self._synthesizer.run(domain_result.draft, similar, route.confidence, user_message)
        trace.append(
            {
                "step": "synthesizer",
                "has_citations": synth.has_citations,
                "latency_ms": int((time.perf_counter() - t3) * 1000),
            }
        )

        total_ms = int((time.perf_counter() - t0) * 1000)
        log.info(
            "orchestrator_resolve",
            domain=route.domain,
            confidence=route.confidence,
            total_ms=total_ms,
        )

        return OrchestratorResult(
            reply=synth.reply,
            domain=route.domain,
            similar_tickets=[
                {
                    "ticket_id": t.ticket_id,
                    "subject": t.subject,
                    "score": t.score,
                    "domain": t.domain,
                }
                for t in similar
            ],
            confidence=route.confidence,
            trace=trace,
        )
