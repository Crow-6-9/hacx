from __future__ import annotations

import pickle
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import structlog

from app.config import CSV_PATH, DATA_SOURCE_URL, FAISS_INDEX_PATH, METADATA_PATH

log = structlog.get_logger()

_TICKET_ID_CANDIDATES = ["Ticket ID", "ticket_id", "id", "ID", "TicketID"]
_SUBJECT_CANDIDATES = ["Ticket Subject", "ticket_subject", "subject", "Subject"]
_DESC_CANDIDATES = ["Ticket Description", "ticket_description", "description", "Description", "Body"]
_RESOLUTION_CANDIDATES = ["Resolution", "resolution", "Solution", "solution"]
_TYPE_CANDIDATES = ["Ticket Type", "ticket_type", "type", "Type", "Category", "category"]


def _find_column(df: pd.DataFrame, candidates: list[str]) -> str | None:
    for c in candidates:
        if c in df.columns:
            return c
    lower_map = {col.lower(): col for col in df.columns}
    for c in candidates:
        if c.lower() in lower_map:
            return lower_map[c.lower()]
    return None


def _load_csv() -> pd.DataFrame:
    if DATA_SOURCE_URL:
        log.info("loading_csv_from_url", url=DATA_SOURCE_URL)
        return pd.read_csv(DATA_SOURCE_URL)
    log.info("loading_csv_from_disk", path=str(CSV_PATH))
    return pd.read_csv(CSV_PATH)


def _normalize_df(df: pd.DataFrame) -> pd.DataFrame:
    col_ticket_id = _find_column(df, _TICKET_ID_CANDIDATES) or df.columns[0]
    col_subject = _find_column(df, _SUBJECT_CANDIDATES)
    col_desc = _find_column(df, _DESC_CANDIDATES)
    col_resolution = _find_column(df, _RESOLUTION_CANDIDATES)
    col_type = _find_column(df, _TYPE_CANDIDATES)

    missing = [
        name
        for name, col in [
            ("subject", col_subject),
            ("description", col_desc),
            ("resolution", col_resolution),
            ("type", col_type),
        ]
        if not col
    ]
    if missing:
        raise ValueError(
            f"Could not find required columns: {missing}. "
            f"Available columns: {list(df.columns)}"
        )

    normalized = pd.DataFrame(
        {
            "ticket_id": df[col_ticket_id].astype(str),
            "subject": df[col_subject].fillna("").astype(str),
            "description": df[col_desc].fillna("").astype(str),
            "resolution": df[col_resolution].fillna("").astype(str),
            "domain": df[col_type]
            .fillna("General")
            .astype(str)
            .str.strip()
            .str.title(),
        }
    )

    normalized = normalized[normalized["resolution"].str.strip() != ""].reset_index(drop=True)
    return normalized


def _get_csv_mtime() -> float:
    if DATA_SOURCE_URL:
        return time.time()
    path = Path(CSV_PATH)
    return path.stat().st_mtime if path.exists() else 0.0


def _get_index_mtime() -> float:
    path = Path(FAISS_INDEX_PATH)
    return path.stat().st_mtime if path.exists() else 0.0


def index_is_fresh() -> bool:
    return (
        FAISS_INDEX_PATH.exists()
        and METADATA_PATH.exists()
        and _get_index_mtime() >= _get_csv_mtime()
    )


def build_index(force: bool = False) -> tuple[Any, list[dict]]:
    if not force and index_is_fresh():
        return load_index()

    log.info("building_index")
    df = _load_csv()
    normalized = _normalize_df(df)
    log.info(
        "csv_loaded",
        total_rows=len(df),
        resolved_rows=len(normalized),
        domains=normalized["domain"].unique().tolist(),
    )

    texts = [
        f"{row.subject} {row.description} {row.resolution}"
        for row in normalized.itertuples()
    ]
    metadata = normalized.to_dict("records")

    embeddings = _compute_embeddings(texts)
    index = _build_faiss_index(embeddings)

    FAISS_INDEX_PATH.parent.mkdir(parents=True, exist_ok=True)
    _save_index(index, metadata)
    log.info("index_built", vectors=len(metadata))
    return index, metadata


def _compute_embeddings(texts: list[str]) -> np.ndarray:
    try:
        from app.llm.client import embed

        log.info("embedding_with_azure_openai", count=len(texts))
        batch_size = 100
        all_embeddings: list[list[float]] = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i : i + batch_size]
            all_embeddings.extend(embed(batch))
            log.debug("embedding_progress", done=min(i + batch_size, len(texts)), total=len(texts))
        return np.array(all_embeddings, dtype="float32")
    except Exception as exc:
        log.warning("embedding_failed_falling_back_to_tfidf", error=str(exc))
        return _tfidf_embeddings(texts)


def _tfidf_embeddings(texts: list[str]) -> np.ndarray:
    from sklearn.feature_extraction.text import TfidfVectorizer

    vectorizer = TfidfVectorizer(max_features=512)
    matrix = vectorizer.fit_transform(texts).toarray().astype("float32")
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    norms[norms == 0] = 1
    return matrix / norms


def _build_faiss_index(embeddings: np.ndarray) -> Any:
    try:
        import faiss

        dim = embeddings.shape[1]
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
        norms[norms == 0] = 1
        normalized = embeddings / norms
        index = faiss.IndexFlatIP(dim)
        index.add(normalized)
        return index
    except ImportError:
        log.warning("faiss_not_available_using_numpy_fallback")
        return {"type": "numpy", "vectors": embeddings}


def _save_index(index: Any, metadata: list[dict]) -> None:
    try:
        import faiss

        if hasattr(index, "ntotal"):
            faiss.write_index(index, str(FAISS_INDEX_PATH))
        else:
            with open(FAISS_INDEX_PATH, "wb") as f:
                pickle.dump(index, f)
    except ImportError:
        with open(FAISS_INDEX_PATH, "wb") as f:
            pickle.dump(index, f)

    with open(METADATA_PATH, "wb") as f:
        pickle.dump(metadata, f)


def load_index() -> tuple[Any, list[dict]]:
    log.info("loading_index_from_disk")
    try:
        import faiss

        index = faiss.read_index(str(FAISS_INDEX_PATH))
    except (ImportError, Exception):
        with open(FAISS_INDEX_PATH, "rb") as f:
            index = pickle.load(f)

    with open(METADATA_PATH, "rb") as f:
        metadata = pickle.load(f)

    return index, metadata


if __name__ == "__main__":
    import structlog

    structlog.configure(
        processors=[
            structlog.dev.ConsoleRenderer(),
        ]
    )
    index, metadata = build_index(force=True)
    print(f"Index built with {len(metadata)} entries.")
    domains = sorted({m["domain"] for m in metadata})
    print(f"Domains: {domains}")
