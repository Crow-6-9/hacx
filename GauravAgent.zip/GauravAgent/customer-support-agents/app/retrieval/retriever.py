from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import structlog

from app.config import TOP_K

log = structlog.get_logger()


@dataclass
class SearchResult:
    ticket_id: str
    subject: str
    description: str
    resolution: str
    domain: str
    score: float


class Retriever:
    def __init__(self, index: Any, metadata: list[dict]) -> None:
        self._index = index
        self._metadata = metadata

    def search(
        self,
        query: str,
        domain: str | None = None,
        k: int = TOP_K,
    ) -> list[SearchResult]:
        query_vec = self._embed_query(query)

        if domain:
            candidate_indices = [
                i
                for i, m in enumerate(self._metadata)
                if m["domain"].lower() == domain.lower()
            ]
        else:
            candidate_indices = list(range(len(self._metadata)))

        if not candidate_indices:
            log.warning("no_candidates_for_domain", domain=domain)
            return []

        results = self._search_in_candidates(query_vec, candidate_indices, k)
        log.debug("retrieval_results", query=query[:80], domain=domain, found=len(results))
        return results

    def _embed_query(self, query: str) -> np.ndarray:
        try:
            from app.llm.client import embed

            vec = np.array(embed([query])[0], dtype="float32")
        except Exception as exc:
            log.warning("embed_query_failed_using_zeros", error=str(exc))
            vec = np.zeros(self._index_dim(), dtype="float32")

        norm = np.linalg.norm(vec)
        if norm > 0:
            vec = vec / norm
        return vec.reshape(1, -1)

    def _index_dim(self) -> int:
        try:
            return self._index.d
        except AttributeError:
            pass
        if isinstance(self._index, dict) and "vectors" in self._index:
            return self._index["vectors"].shape[1]
        return 512

    def _search_in_candidates(
        self,
        query_vec: np.ndarray,
        candidate_indices: list[int],
        k: int,
    ) -> list[SearchResult]:
        try:
            import faiss  # noqa: F401

            if hasattr(self._index, "ntotal"):
                return self._faiss_search(query_vec, candidate_indices, k)
        except ImportError:
            pass
        return self._numpy_search(query_vec, candidate_indices, k)

    def _faiss_search(
        self,
        query_vec: np.ndarray,
        candidate_indices: list[int],
        k: int,
    ) -> list[SearchResult]:
        search_k = min(k * 10, self._index.ntotal)
        scores, indices = self._index.search(query_vec, search_k)

        results: list[SearchResult] = []
        candidate_set = set(candidate_indices)
        for score, idx in zip(scores[0], indices[0]):
            if idx == -1:
                continue
            if idx in candidate_set:
                m = self._metadata[idx]
                results.append(
                    SearchResult(
                        ticket_id=m["ticket_id"],
                        subject=m["subject"],
                        description=m["description"],
                        resolution=m["resolution"],
                        domain=m["domain"],
                        score=float(score),
                    )
                )
            if len(results) >= k:
                break
        return results

    def _numpy_search(
        self,
        query_vec: np.ndarray,
        candidate_indices: list[int],
        k: int,
    ) -> list[SearchResult]:
        idx_obj = self._index
        if not (isinstance(idx_obj, dict) and "vectors" in idx_obj):
            return []

        vectors = idx_obj["vectors"][candidate_indices]
        scores = (vectors @ query_vec.T).flatten()
        top_positions = np.argsort(scores)[::-1][:k]

        return [
            SearchResult(
                ticket_id=self._metadata[candidate_indices[pos]]["ticket_id"],
                subject=self._metadata[candidate_indices[pos]]["subject"],
                description=self._metadata[candidate_indices[pos]]["description"],
                resolution=self._metadata[candidate_indices[pos]]["resolution"],
                domain=self._metadata[candidate_indices[pos]]["domain"],
                score=float(scores[pos]),
            )
            for pos in top_positions
        ]
