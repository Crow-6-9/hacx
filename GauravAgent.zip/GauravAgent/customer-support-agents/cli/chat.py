from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv

load_dotenv()

import structlog
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Prompt
from rich.table import Table

from app.orchestrator import Orchestrator, OrchestratorResult
from app.retrieval.indexer import build_index, index_is_fresh, load_index
from app.retrieval.retriever import Retriever

structlog.configure(
    processors=[
        structlog.stdlib.add_log_level,
        structlog.dev.ConsoleRenderer(),
    ]
)

console = Console()
_last_result: OrchestratorResult | None = None
_history: list[dict] = []


def _get_domains(metadata: list[dict]) -> list[str]:
    domains = sorted({m["domain"] for m in metadata})
    if "General" not in domains:
        domains.append("General")
    return domains


def _build_or_load() -> tuple[Any, list[dict]]:
    if not index_is_fresh():
        console.print("[yellow]Building vector index from CSV — this may take a minute...[/yellow]")
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Embedding tickets...", total=None)
            index, metadata = build_index(force=True)
            progress.update(task, completed=True)
        console.print(f"[green]Index built: {len(metadata)} resolved tickets indexed.[/green]")
    else:
        console.print("[dim]Loading cached index...[/dim]")
        index, metadata = load_index()
        console.print(f"[dim]Loaded {len(metadata)} resolved tickets.[/dim]")
    return index, metadata


def _handle_command(cmd: str) -> bool:
    global _history, _last_result
    token = cmd.strip().lower()

    if token == "/quit":
        console.print("[bold red]Goodbye![/bold red]")
        sys.exit(0)

    if token == "/reset":
        _history = []
        console.print("[yellow]Conversation history cleared.[/yellow]")
        return True

    if token == "/domain":
        if _last_result:
            console.print(
                f"[bold]Last domain:[/bold] {_last_result.domain}  "
                f"(confidence: {_last_result.confidence:.2f})"
            )
        else:
            console.print("[dim]No messages sent yet.[/dim]")
        return True

    if token == "/similar":
        if _last_result and _last_result.similar_tickets:
            table = Table(title="Similar Past Tickets", show_header=True, header_style="bold magenta")
            table.add_column("Ticket ID", style="cyan", no_wrap=True)
            table.add_column("Subject", style="white")
            table.add_column("Domain", style="magenta")
            table.add_column("Score", style="green", justify="right")
            for t in _last_result.similar_tickets:
                table.add_row(
                    str(t["ticket_id"]),
                    str(t["subject"])[:60],
                    t["domain"],
                    f"{t['score']:.3f}",
                )
            console.print(table)
        else:
            console.print("[dim]No similar tickets retrieved yet.[/dim]")
        return True

    if token == "/help":
        console.print(
            Markdown(
                "**Commands:**\n"
                "- `/domain` — show which agent handled the last turn\n"
                "- `/similar` — show top-k similar past tickets with scores\n"
                "- `/reset` — clear conversation history\n"
                "- `/quit` — exit\n"
            )
        )
        return True

    return False


def main() -> None:
    global _last_result

    console.print(
        Panel.fit(
            "[bold blue]Customer Support Resolution Agent[/bold blue]\n"
            "Type your support question, or [bold]/help[/bold] for commands.",
            border_style="blue",
        )
    )

    try:
        index, metadata = _build_or_load()
    except FileNotFoundError:
        console.print(
            "[bold red]Error:[/bold red] data/customer_support_tickets.csv not found.\n"
            "Place the CSV in the data/ directory and retry."
        )
        sys.exit(1)
    except Exception as exc:
        console.print(f"[bold red]Failed to load index:[/bold red] {exc}")
        sys.exit(1)

    domains = _get_domains(metadata)
    retriever = Retriever(index, metadata)
    orchestrator = Orchestrator(retriever, domains)

    console.print(f"[dim]Domains: {', '.join(domains)}[/dim]\n")

    while True:
        try:
            user_input = Prompt.ask("[bold green]You[/bold green]")
        except (KeyboardInterrupt, EOFError):
            console.print("\n[bold red]Goodbye![/bold red]")
            break

        if not user_input.strip():
            continue

        if user_input.startswith("/"):
            _handle_command(user_input)
            continue

        with console.status("[bold blue]Resolving...[/bold blue]", spinner="dots"):
            try:
                result = orchestrator.resolve(user_input, _history)
            except Exception as exc:
                console.print(f"[bold red]Error:[/bold red] {exc}")
                continue

        _last_result = result
        _history.append({"role": "user", "content": user_input})
        _history.append({"role": "assistant", "content": result.reply})

        console.print(
            Panel(
                Markdown(result.reply),
                title=f"[bold blue]Agent ({result.domain}) — confidence {result.confidence:.2f}[/bold blue]",
                border_style="blue",
            )
        )


if __name__ == "__main__":
    main()
