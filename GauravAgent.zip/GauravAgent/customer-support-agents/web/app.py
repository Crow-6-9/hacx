from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv

load_dotenv()

from contextlib import asynccontextmanager
from typing import Any

import structlog
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

from app.orchestrator import Orchestrator, OrchestratorResult
from app.retrieval.indexer import build_index, index_is_fresh, load_index
from app.retrieval.retriever import Retriever

log = structlog.get_logger()

_orchestrator: Orchestrator | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _orchestrator
    if not index_is_fresh():
        log.info("web_building_index")
        index, metadata = build_index(force=True)
    else:
        index, metadata = load_index()
    domains = sorted({m["domain"] for m in metadata})
    if "General" not in domains:
        domains.append("General")
    retriever = Retriever(index, metadata)
    _orchestrator = Orchestrator(retriever, domains)
    log.info("web_ready", domains=domains, tickets=len(metadata))
    yield


app = FastAPI(title="Customer Support Agent", lifespan=lifespan)


class ChatRequest(BaseModel):
    message: str
    history: list[dict] = []


class ChatResponse(BaseModel):
    reply: str
    domain: str
    confidence: float
    similar_tickets: list[dict]
    trace: list[dict]


@app.post("/chat", response_model=ChatResponse)
async def chat_endpoint(req: ChatRequest) -> Any:
    if _orchestrator is None:
        raise HTTPException(status_code=503, detail="Orchestrator not ready")
    result: OrchestratorResult = _orchestrator.resolve(req.message, req.history)
    return ChatResponse(
        reply=result.reply,
        domain=result.domain,
        confidence=result.confidence,
        similar_tickets=result.similar_tickets,
        trace=result.trace,
    )


_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Customer Support Agent</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: system-ui, sans-serif; background: #f5f5f5; display: flex; flex-direction: column; height: 100vh; }
  header { background: #1a56db; color: white; padding: 1rem 1.5rem; font-size: 1.2rem; font-weight: 600; }
  #chat-window { flex: 1; overflow-y: auto; padding: 1.5rem; display: flex; flex-direction: column; gap: 1rem; }
  .msg { max-width: 75%; padding: 0.75rem 1rem; border-radius: 12px; line-height: 1.5; white-space: pre-wrap; }
  .user { align-self: flex-end; background: #1a56db; color: white; }
  .agent { align-self: flex-start; background: white; box-shadow: 0 1px 4px rgba(0,0,0,.12); }
  .meta { font-size: 0.75rem; color: #888; margin-top: 0.25rem; align-self: flex-start; }
  details { margin-top: 0.5rem; font-size: 0.8rem; color: #555; }
  summary { cursor: pointer; color: #1a56db; }
  table { border-collapse: collapse; width: 100%; margin-top: 0.5rem; }
  th, td { text-align: left; padding: 0.25rem 0.5rem; border-bottom: 1px solid #eee; font-size: 0.78rem; }
  #input-row { display: flex; gap: 0.5rem; padding: 1rem 1.5rem; background: white; border-top: 1px solid #e5e5e5; }
  #msg-input { flex: 1; padding: 0.65rem 1rem; border: 1px solid #ccc; border-radius: 8px; font-size: 1rem; }
  #send-btn { padding: 0.65rem 1.4rem; background: #1a56db; color: white; border: none; border-radius: 8px; cursor: pointer; font-size: 1rem; }
  #send-btn:disabled { opacity: 0.5; cursor: not-allowed; }
  .spinner { display: inline-block; width: 14px; height: 14px; border: 2px solid #ccc; border-top-color: #1a56db; border-radius: 50%; animation: spin 0.7s linear infinite; }
  @keyframes spin { to { transform: rotate(360deg); } }
</style>
</head>
<body>
<header>Customer Support Agent</header>
<div id="chat-window"></div>
<div id="input-row">
  <input id="msg-input" type="text" placeholder="Describe your issue..." autocomplete="off"/>
  <button id="send-btn">Send</button>
</div>
<script>
const win = document.getElementById('chat-window');
const input = document.getElementById('msg-input');
const btn = document.getElementById('send-btn');
let history = [];

function appendMsg(text, cls) {
  const div = document.createElement('div');
  div.className = 'msg ' + cls;
  div.textContent = text;
  win.appendChild(div);
  win.scrollTop = win.scrollHeight;
  return div;
}

function appendAgent(data) {
  const div = document.createElement('div');
  div.className = 'msg agent';
  div.textContent = data.reply;
  win.appendChild(div);

  const meta = document.createElement('div');
  meta.className = 'meta';
  meta.textContent = `Domain: ${data.domain} | Confidence: ${(data.confidence*100).toFixed(0)}%`;
  win.appendChild(meta);

  if (data.similar_tickets && data.similar_tickets.length) {
    const det = document.createElement('details');
    const sum = document.createElement('summary');
    sum.textContent = `${data.similar_tickets.length} similar past ticket(s)`;
    det.appendChild(sum);
    const tbl = document.createElement('table');
    tbl.innerHTML = '<tr><th>ID</th><th>Subject</th><th>Domain</th><th>Score</th></tr>';
    data.similar_tickets.forEach(t => {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${t.ticket_id}</td><td>${t.subject.slice(0,60)}</td><td>${t.domain}</td><td>${t.score.toFixed(3)}</td>`;
      tbl.appendChild(tr);
    });
    det.appendChild(tbl);
    win.appendChild(det);
  }
  win.scrollTop = win.scrollHeight;
}

async function send() {
  const text = input.value.trim();
  if (!text) return;
  input.value = '';
  btn.disabled = true;

  appendMsg(text, 'user');
  const loading = appendMsg('', 'agent');
  const spin = document.createElement('span');
  spin.className = 'spinner';
  loading.appendChild(spin);
  win.scrollTop = win.scrollHeight;

  try {
    const res = await fetch('/chat', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({message: text, history})
    });
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    loading.remove();
    appendAgent(data);
    history.push({role:'user', content:text});
    history.push({role:'assistant', content:data.reply});
  } catch (err) {
    loading.textContent = 'Error: ' + err.message;
  }
  btn.disabled = false;
  input.focus();
}

btn.addEventListener('click', send);
input.addEventListener('keydown', e => { if (e.key === 'Enter') send(); });
</script>
</body>
</html>
"""


@app.get("/", response_class=HTMLResponse)
async def index() -> str:
    return _HTML
