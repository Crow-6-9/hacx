# Azure AI Foundry Deployment Guide

## A. Provisioning in Azure AI Foundry

### 1. Create a Foundry Project

1. Go to [https://ai.azure.com](https://ai.azure.com) and sign in.
2. Click **+ New project**.
3. Choose or create an **AI Hub** (acts as the parent resource with shared networking/keys).
4. Name your project (e.g. `customer-support-agents`) and click **Create**.

### 2. Deploy a Chat Model

1. In your project, go to **Deployments** → **+ Deploy model**.
2. Select `gpt-4o` (or `gpt-4o-mini` for cost savings).
3. Set the **Deployment name** — this becomes `AZURE_OPENAI_MODEL` (e.g. `gpt-4o`).
4. Choose a region and quota tier. Click **Deploy**.

### 3. Deploy an Embeddings Model

1. Go to **Deployments** → **+ Deploy model** again.
2. Select `text-embedding-3-small`.
3. Set the **Deployment name** — this becomes `AZURE_OPENAI_EMBEDDING_MODEL` (e.g. `text-embedding-3-small`).
4. Click **Deploy**.

### 4. Get the Endpoint and API Key

1. Go to **Settings** → **Keys and Endpoints** in your Foundry project.
2. Copy the **Endpoint** URL. It must end in `/openai/v1/` for the OpenAI SDK pattern.
   - Example: `https://my-project.openai.azure.com/openai/v1/`
3. Copy **Key 1** — this becomes `AZURE_OPENAI_API_KEY`.

---

## B. Data Handling

### Upload CSV to Azure Blob Storage

```bash
# Create a storage account and container
az storage account create \
  --name mystorageacct \
  --resource-group my-rg \
  --sku Standard_LRS \
  --location eastus

az storage container create \
  --name supportdata \
  --account-name mystorageacct

# Upload the CSV
az storage blob upload \
  --account-name mystorageacct \
  --container-name supportdata \
  --name customer_support_tickets.csv \
  --file ./data/customer_support_tickets.csv

# Generate a SAS token (valid 1 year)
az storage blob generate-sas \
  --account-name mystorageacct \
  --container-name supportdata \
  --name customer_support_tickets.csv \
  --permissions r \
  --expiry 2027-01-01 \
  --https-only \
  --output tsv
```

Set the env var:
```
DATA_SOURCE_URL=https://mystorageacct.blob.core.windows.net/supportdata/customer_support_tickets.csv?<sas-token>
```

### Persist the FAISS Index to Blob Storage

For production, upload `data/index.faiss` and `data/metadata.pkl` after the first build:

```bash
az storage blob upload-batch \
  --account-name mystorageacct \
  --destination supportdata \
  --source ./data \
  --pattern "index.faiss|metadata.pkl"
```

Update `app/retrieval/indexer.py` to download these blobs on startup when `DATA_SOURCE_URL` is set — containers then skip the rebuild on every restart.

---

## C. Containerization

### Build and Push to Azure Container Registry

```bash
# Create ACR
az acr create \
  --name myagentregistry \
  --resource-group my-rg \
  --sku Basic

# Build and push directly (no local Docker needed)
az acr build \
  --registry myagentregistry \
  --image customer-support-agents:latest \
  --file deploy/Dockerfile \
  .
```

---

## D. Hosting — Path 1 (Recommended): Azure Container Apps

### Create the Container App Environment

```bash
az containerapp env create \
  --name support-agents-env \
  --resource-group my-rg \
  --location eastus
```

### Deploy the Container App

```bash
az containerapp create \
  --name customer-support-agents \
  --resource-group my-rg \
  --environment support-agents-env \
  --image myagentregistry.azurecr.io/customer-support-agents:latest \
  --registry-server myagentregistry.azurecr.io \
  --target-port 8000 \
  --ingress external \
  --min-replicas 1 \
  --max-replicas 5 \
  --scale-rule-name http-concurrency \
  --scale-rule-type http \
  --scale-rule-http-concurrency 20 \
  --env-vars \
    AZURE_OPENAI_ENDPOINT=https://my-project.openai.azure.com/openai/v1/ \
    AZURE_OPENAI_MODEL=gpt-4o \
    AZURE_OPENAI_EMBEDDING_MODEL=text-embedding-3-small \
    "AZURE_OPENAI_API_KEY=secretref:openai-api-key"
```

The app will be reachable at the FQDN shown in the output (e.g. `https://customer-support-agents.<hash>.eastus.azurecontainerapps.io`).

---

## E. Secrets — Azure Key Vault

### Store the API Key

```bash
az keyvault create \
  --name support-agents-kv \
  --resource-group my-rg \
  --location eastus

az keyvault secret set \
  --vault-name support-agents-kv \
  --name openai-api-key \
  --value "your-actual-api-key"
```

### Grant the Container App Managed Identity Access

```bash
# Enable system-assigned managed identity on the Container App
az containerapp identity assign \
  --name customer-support-agents \
  --resource-group my-rg \
  --system-assigned

# Get the principal ID
PRINCIPAL_ID=$(az containerapp show \
  --name customer-support-agents \
  --resource-group my-rg \
  --query identity.principalId -o tsv)

# Grant Key Vault Secrets User role
az role assignment create \
  --assignee $PRINCIPAL_ID \
  --role "Key Vault Secrets User" \
  --scope $(az keyvault show --name support-agents-kv --query id -o tsv)
```

### Reference the Secret in Container App

Update the env var to use a Key Vault reference:

```bash
az containerapp update \
  --name customer-support-agents \
  --resource-group my-rg \
  --set-env-vars \
    "AZURE_OPENAI_API_KEY=@Microsoft.KeyVault(VaultName=support-agents-kv;SecretName=openai-api-key)"
```

---

## F. Observability — Application Insights

### Enable Application Insights

```bash
az monitor app-insights component create \
  --app support-agents-insights \
  --location eastus \
  --resource-group my-rg \
  --kind web

APPINSIGHTS_KEY=$(az monitor app-insights component show \
  --app support-agents-insights \
  --resource-group my-rg \
  --query instrumentationKey -o tsv)

az containerapp update \
  --name customer-support-agents \
  --resource-group my-rg \
  --set-env-vars APPLICATIONINSIGHTS_CONNECTION_STRING="InstrumentationKey=$APPINSIGHTS_KEY"
```

### Structured Logging

The app uses `structlog` with JSON output. Each agent hop logs:
- `router_decision`: domain, confidence
- `retrieval_results`: found tickets, domain
- `domain_agent_done`: domain, cited_tickets count
- `synthesizer_done`: has_citations, above_threshold count
- `orchestrator_resolve`: domain, confidence, total_ms

### Sample KQL Queries (Log Analytics / App Insights)

**Most common domain:**
```kql
traces
| where message has "orchestrator_resolve"
| extend domain = tostring(parse_json(customDimensions).domain)
| summarize count() by domain
| order by count_ desc
```

**P95 end-to-end latency:**
```kql
traces
| where message has "orchestrator_resolve"
| extend latency = toint(parse_json(customDimensions).total_ms)
| summarize p95=percentile(latency, 95), p50=percentile(latency, 50) by bin(timestamp, 1h)
```

**Low-confidence resolutions (possible escalations):**
```kql
traces
| where message has "orchestrator_resolve"
| extend confidence = todouble(parse_json(customDimensions).confidence)
| where confidence < 0.5
| project timestamp, domain=tostring(parse_json(customDimensions).domain), confidence
| order by timestamp desc
```

---

## H. Cost & Scaling Notes

### Token Cost Estimate per Resolution

| Component | ~Tokens | Notes |
|-----------|---------|-------|
| Router prompt | ~300 | Domains list + user message |
| Domain agent prompt | ~1,500 | 5 similar tickets + user message |
| Synthesizer prompt | ~800 | Draft + formatting instructions |
| **Total per resolution** | **~2,600** | At gpt-4o pricing (~$5/M input tokens) ≈ **$0.013/resolution** |

Embedding: ~200 tokens per query × $0.02/M = negligible.

### When to Switch from FAISS to Azure AI Search

FAISS on disk works well up to ~100k tickets (index stays under ~500 MB for 1536-dim embeddings). Beyond that:

1. Index rebuild time exceeds acceptable cold-start time (>30s).
2. Memory pressure on container instances becomes significant.
3. You need filtering by multiple metadata fields, hybrid keyword+semantic search, or ACL-based access.

At that point, replace `app/retrieval/retriever.py` with the [Azure AI Search Python SDK](https://learn.microsoft.com/azure/search/search-get-started-vector) using a vector index. The `Retriever.search()` interface stays the same — only the backend changes.
