# Claude Code Prompt: Multi-Agent Customer Support Resolution System

## Project Overview

Build a production-ready **multi-agent customer support chatbot** that routes incoming tickets to domain-specialized agents, performs semantic similarity search against historical resolutions, and generates grounded responses using Azure OpenAI (accessed via the OpenAI Python SDK pointed at an Azure endpoint).

The deliverable is a complete Python project with:
1. A multi-agent resolution engine (router + domain agents + retrieval layer).
2. A local CLI + web chatbot for testing.
3. A full Azure AI Foundry deployment guide.
4. A `README.md` / `RUN_LOCAL.md` that a new engineer can follow end-to-end.



## Input Data

A file `customer_support_tickets.csv` exists at the project root. **Do not assume its exact schema** — the first thing the code must do is introspect the CSV with pandas and adapt. However, typical columns include:

- `Ticket ID`, `Customer Name`, `Customer Email`, `Customer Age`, `Customer Gender`
- `Product Purchased`, `Date of Purchase`
- `Ticket Type` (e.g. Billing, Technical, Cancellation, Refund, Product inquiry)
- `Ticket Subject`, `Ticket Description`
- `Ticket Status`, `Resolution`, `Ticket Priority`, `Ticket Channel`
- `First Response Time`, `Time to Resolution`, `Customer Satisfaction Rating`

**Rules for handling the data:**
- Only use rows where `Resolution` is non-empty / non-null as the knowledge base for similarity search (closed tickets with actual resolutions).
- Normalize `Ticket Type` values (strip, title-case) and use them as the **domain routing key**.
- If the CSV has different column names, write a small adapter that maps them — do not hardcode assumptions without a fallback.

---

## Model Client — Exact Pattern to Use

The project must call the model exactly like this (this is the user's existing working pattern — do not replace it with `AzureOpenAI` or `langchain_openai`):

```python
import os
from openai import OpenAI

ENDPOINT = "https://<your-foundry-endpoint>/openai/v1/"  # fallback default

def get_client() -> OpenAI:
    return OpenAI(
        base_url=os.getenv("AZURE_OPENAI_ENDPOINT", ENDPOINT),
        api_key=os.environ["AZURE_OPENAI_API_KEY"],
    )

def get_model() -> str:
    return os.getenv("AZURE_OPENAI_MODEL", "gpt-4o")

def chat(system: str, user: str, max_tokens: int = 1024) -> str:
    client = get_client()
    response = client.chat.completions.create(
        model=get_model(),
        max_completion_tokens=max_tokens,
        messages=[
            {"role": "system", "content": system},
            {"role": "user": user},
        ],
        temperature=0,
    )
    return response.choices[0].message.content
```

Wrap this in `app/llm/client.py`. Every agent must go through this single helper — no direct `OpenAI()` instantiations scattered across files.

**Environment variables** (document these in `.env.example`):
- `AZURE_OPENAI_ENDPOINT` — full base URL ending in `/openai/v1/`
- `AZURE_OPENAI_API_KEY`
- `AZURE_OPENAI_MODEL` — chat model deployment name (e.g. `gpt-4o`)
- `AZURE_OPENAI_EMBEDDING_MODEL` — embedding deployment name (e.g. `text-embedding-3-small`)

---

## Architecture — Multi-Agent Design

Implement the following agents. Each agent is a class with a `run(query: str, context: dict) -> AgentResponse` method.

### 1. `RouterAgent` (`app/agents/router.py`)
- Takes the raw user message.
- Uses the LLM with a classification prompt to pick one of the domain agents based on the unique `Ticket Type` values discovered in the CSV.
- Falls back to `GeneralAgent` if confidence is low or type is unknown.
- Returns `{"domain": "Billing", "confidence": 0.92, "reasoning": "..."}`.

### 2. Domain Agents (`app/agents/domain.py`)
Create one class `DomainAgent` that is **parameterized by domain name** (so you get Billing / Technical / Refund / Cancellation / Product Inquiry agents from the same code). Each instance:
- Receives the user query + the top-k retrieved historical resolutions scoped to its domain.
- Builds a grounded prompt (see template below).
- Calls the LLM and returns a draft resolution + cited past-ticket IDs.

### 3. `RetrievalAgent` (`app/retrieval/retriever.py`)
- On startup, builds a vector index over all historical tickets with resolutions.
- Embedding strategy: use Azure OpenAI embeddings through the same `OpenAI` client (`client.embeddings.create(...)`). Combine `Ticket Subject + Ticket Description + Resolution` into the embedded text, but store the resolution separately for grounding.
- Store vectors in a local **FAISS** index (file: `data/index.faiss`) with a parallel pickle `data/metadata.pkl` holding the dataframe rows.
- Expose `search(query: str, domain: str | None = None, k: int = 5)` — filters by domain first, then semantic-ranks.
- Cache the index to disk; rebuild only if `customer_support_tickets.csv` mtime is newer than the index.

### 4. `SynthesizerAgent` (`app/agents/synthesizer.py`)
- Combines router decision + retrieved cases + domain agent's draft into the final user-facing reply.
- Enforces a consistent response shape: greeting → diagnosis → resolution steps → escalation path (if needed) → references to similar past tickets (by ID).

### 5. `Orchestrator` (`app/orchestrator.py`)
- The public entry point. Exposes `resolve(user_message: str, conversation_history: list) -> dict`.
- Pipeline: `RouterAgent` → `RetrievalAgent` → `DomainAgent` → `SynthesizerAgent`.
- Returns structured output: `{"reply": str, "domain": str, "similar_tickets": [...], "confidence": float, "trace": [...]}`.

---

## Grounded Resolution Prompt Template

The domain agent must use a prompt like this (store as a Jinja2 template in `app/prompts/domain_resolution.j2`):

```
You are a senior customer support specialist for the {{ domain }} domain.
You must answer the customer using ONLY the patterns found in the past resolutions below.
If the past resolutions do not cover the issue, say so and escalate to a human agent.

=== SIMILAR PAST TICKETS ===
{% for t in similar_tickets %}
[Ticket {{ t.ticket_id }}] (similarity: {{ "%.2f"|format(t.score) }})
Subject: {{ t.subject }}
Problem: {{ t.description }}
Resolution used: {{ t.resolution }}
---
{% endfor %}

=== CURRENT CUSTOMER MESSAGE ===
{{ user_message }}

Respond with:
1. A one-line diagnosis.
2. Numbered resolution steps grounded in the past resolutions above.
3. If applicable: which past ticket IDs you drew from.
4. An escalation note if confidence is low.
```

---

## Project Structure

```
customer-support-agents/
├── app/
│   ├── __init__.py
│   ├── orchestrator.py
│   ├── llm/
│   │   ├── __init__.py
│   │   └── client.py              # get_client(), get_model(), chat(), embed()
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── router.py
│   │   ├── domain.py
│   │   └── synthesizer.py
│   ├── retrieval/
│   │   ├── __init__.py
│   │   ├── retriever.py           # FAISS-based
│   │   └── indexer.py             # builds/loads the index from CSV
│   ├── prompts/
│   │   ├── router.j2
│   │   └── domain_resolution.j2
│   └── config.py                  # env vars, paths
├── data/
│   ├── customer_support_tickets.csv
│   ├── index.faiss                # generated
│   └── metadata.pkl               # generated
├── cli/
│   └── chat.py                    # Rich-based CLI chatbot
├── web/
│   └── app.py                     # FastAPI + simple HTML chat UI
├── tests/
│   ├── test_retriever.py
│   ├── test_router.py
│   └── test_orchestrator.py
├── deploy/
│   ├── Dockerfile
│   ├── azure-foundry-guide.md     # THE deployment guide
│   └── bicep/                     # optional IaC
├── .env.example
├── requirements.txt
├── pyproject.toml
├── README.md
└── RUN_LOCAL.md
```

---

## Deliverable 1 — Local CLI Chatbot

`cli/chat.py` using `rich` for a nice terminal UI. Behavior:
- On first run, builds the FAISS index (shows a progress bar).
- REPL loop: user types a message, orchestrator resolves, reply is rendered as a Markdown panel.
- `/domain` command shows which agent handled the last turn.
- `/similar` command shows the top-k retrieved past tickets with IDs and similarity scores.
- `/reset` clears conversation history.
- `/quit` exits.

## Deliverable 2 — Local Web Chatbot

`web/app.py` — minimal FastAPI app with:
- `POST /chat` → `{message, history}` returns orchestrator output as JSON.
- `GET /` serves a single-file HTML chat UI (vanilla JS, no build step) that shows the reply and a collapsible "similar past tickets" panel.
- Runs with `uvicorn web.app:app --reload`.

## Deliverable 3 — `RUN_LOCAL.md`

Must contain, in this order:
1. Prerequisites (Python 3.11+, an Azure OpenAI resource with a chat deployment and an embeddings deployment).
2. `git clone` → `cd` → `python -m venv .venv` → activate → `pip install -r requirements.txt`.
3. Copy `.env.example` to `.env` and fill in the four env vars. Show exactly where to find each value in the Azure AI Foundry portal.
4. Put `customer_support_tickets.csv` into `data/`.
5. Build the index: `python -m app.retrieval.indexer` (one-time; auto-rebuilds on CSV changes).
6. Run the CLI: `python -m cli.chat`.
7. Run the web UI: `uvicorn web.app:app --reload` → open `http://localhost:8000`.
8. Run tests: `pytest -q`.
9. Troubleshooting section: missing env vars, 401s, empty retrieval results, embedding quota errors.

## Deliverable 4 — Azure AI Foundry Deployment Guide

`deploy/azure-foundry-guide.md` — an actual step-by-step, not a wishlist. Cover:

**A. Provisioning in Azure AI Foundry**
- Create a Foundry project (hub + project).
- Deploy a chat model (e.g. `gpt-4o`) and an embeddings model (`text-embedding-3-small`). Note the deployment names — these become `AZURE_OPENAI_MODEL` and `AZURE_OPENAI_EMBEDDING_MODEL`.
- Get the endpoint URL (must end in `/openai/v1/` for the OpenAI SDK pattern we use) and generate an API key.

**B. Data handling**
- Upload `customer_support_tickets.csv` to an Azure Storage blob container.
- Update the app to optionally read the CSV from blob storage (use env var `DATA_SOURCE_URL`; fall back to local file).
- Persist the FAISS index + metadata to the same container so containers don't rebuild on every start.

**C. Containerization**
- The provided `Dockerfile` (multi-stage, python:3.11-slim base).
- Build + push to Azure Container Registry: exact `az acr build` command.

**D. Hosting — pick ONE path and fully document it:**
- **Path 1 (recommended): Azure Container Apps** — `az containerapp create` with env var injection from Key Vault references, ingress on port 8000, scale rules (min 1, max 5, HTTP concurrency 20).
- **Path 2: Azure AI Foundry Agent Service** — register the orchestrator as a custom agent, wire tool calls for router/retrieval/synthesizer. Include exact portal steps + the agent YAML.

**E. Secrets**
- Store `AZURE_OPENAI_API_KEY` in Azure Key Vault.
- Grant the Container App's managed identity `get` permission.
- Reference it as `@Microsoft.KeyVault(...)` in the Container App env vars.

**F. Observability**
- Enable Application Insights; log every agent hop (router decision, retrieved ticket IDs, latency, token usage) with structured logging.
- Sample KQL queries for "most common domain", "p95 latency", "low-confidence resolutions".


**H. Cost & scaling notes**
- Token cost per resolution estimate.
- When to switch from FAISS-on-disk to Azure AI Search (roughly >100k tickets).

---

## Quality Bar — Non-Negotiables

- **Type hints everywhere**, `from __future__ import annotations`, `ruff` + `black` clean.
- **No secrets in code**. Everything via env vars with `.env.example` documented.
- **Graceful degradation**: if the embeddings endpoint fails, fall back to TF-IDF via scikit-learn so the CLI still runs for local dev.
- **Tests**: at minimum, a happy-path test per agent using a mocked `chat()` function, plus one integration test that runs the full orchestrator against 3 synthetic tickets.
- **Logging**: structlog with JSON output in production, pretty output locally.
- **Resolution grounding**: the synthesizer must include at least one `[Ticket #...]` citation whenever retrieval returned results above a similarity threshold (default 0.6). If nothing is above threshold, it must say "I don't have a close historical match — escalating."
- **Conversation memory**: orchestrator accepts a `history` list and passes the last 6 turns into the domain agent prompt.

---

## What to Build First (Execution Order)

1. Scaffold the folder structure and `pyproject.toml` / `requirements.txt`.
2. `app/llm/client.py` + a smoke test that calls the model with "ping".
3. `app/retrieval/indexer.py` + `retriever.py` — get FAISS search working against the CSV.
4. `RouterAgent`, then `DomainAgent`, then `SynthesizerAgent`, then `Orchestrator`.
5. `cli/chat.py` — verify end-to-end locally.
6. `web/app.py` — same orchestrator, HTTP wrapper.
7. Tests.
8. `RUN_LOCAL.md`.
9. `deploy/azure-foundry-guide.md` + `Dockerfile` + GitHub Actions.

Please confirm the architecture, then start at step 1 and work sequentially. Show me the file tree after step 1, and pause after step 5 so I can test the CLI before we build the web UI and deployment artifacts.
