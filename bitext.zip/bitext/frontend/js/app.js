const queryInput = document.getElementById('queryInput');
const autocompleteList = document.getElementById('autocompleteList');
const submitBtn = document.getElementById('submitBtn');
const loading = document.getElementById('loading');
const ticketArea = document.getElementById('ticketArea');

let currentTicketId = null;
let pollInterval = null;

// Autocomplete Logic
let debounceTimer;
queryInput.addEventListener('input', function() {
    const val = this.value;
    autocompleteList.innerHTML = '';
    if (!val) return;

    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(async () => {
        try {
            const res = await fetch(`/api/autocomplete?q=${encodeURIComponent(val)}`);
            const data = await res.json();
            
            data.suggestions.forEach(suggestion => {
                const div = document.createElement('div');
                div.className = 'autocomplete-item';
                div.innerHTML = suggestion;
                div.addEventListener('click', function() {
                    queryInput.value = suggestion;
                    autocompleteList.innerHTML = '';
                });
                autocompleteList.appendChild(div);
            });
        } catch (e) {
            console.error("Autocomplete failed", e);
        }
    }, 300);
});

// Close autocomplete on click outside
document.addEventListener('click', function (e) {
    if (e.target !== queryInput) {
        autocompleteList.innerHTML = '';
    }
});

// Create Ticket
submitBtn.addEventListener('click', async () => {
    const query = queryInput.value.trim();
    if (!query) return;

    loading.style.display = 'block';
    submitBtn.disabled = true;
    ticketArea.innerHTML = '';
    clearInterval(pollInterval);

    try {
        const res = await fetch('/api/tickets', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query: query })
        });
        const ticket = await res.json();
        currentTicketId = ticket.id;
        renderTicket(ticket);
    } catch (e) {
        ticketArea.innerHTML = `<div style="color: red; margin-top: 1rem;">Failed to connect to backend: ${e.message}</div>`;
    } finally {
        loading.style.display = 'none';
        submitBtn.disabled = false;
    }
});

function getStatusLabel(status) {
    const map = {
        'PENDING_FEEDBACK': 'Pending Feedback',
        'AUTO_RESOLVED': 'Auto-Resolved',
        'ESCALATED_IT': 'Escalated to IT Admin',
        'PENDING_USER_VERIFICATION': 'Pending Your Verification',
        'CLOSED_RESOLVED': 'Closed (Resolved)'
    };
    return map[status] || status;
}

function renderTicket(ticket) {
    let html = `
        <div class="ticket-response">
            <div style="font-size: 0.8rem; color: #6B7280; margin-bottom: 0.5rem;">Ticket ID: ${ticket.id}</div>
            <div class="ticket-status status-${ticket.status}">${getStatusLabel(ticket.status)}</div>
            
            <div style="margin-bottom: 1rem;"><strong>Your Query:</strong> ${ticket.user_query}</div>
            <div><strong>AI Assistant:</strong><br> ${ticket.model_response.replace(/\\n/g, '<br>')}</div>
    `;

    if (ticket.status === 'PENDING_FEEDBACK') {
        html += `
            <div class="feedback-section">
                <p><strong>Did this resolve your issue?</strong></p>
                <div class="feedback-buttons">
                    <button class="btn-success" onclick="submitFeedback(true)">Yes, it worked</button>
                    <button class="btn-danger" onclick="submitFeedback(false)">No, escalate to IT</button>
                </div>
            </div>
        `;
    } else if (ticket.status === 'ESCALATED_IT') {
        html += `
            <div class="feedback-section">
                <p><em>Your ticket has been escalated. Please wait for an IT admin to review...</em></p>
                <div class="loading" style="display:block">Polling for updates...</div>
            </div>
        `;
        startPolling();
    } else if (ticket.status === 'PENDING_USER_VERIFICATION') {
        html += `
            <div class="admin-instruction-box">
                <p><strong>Message from IT Admin:</strong></p>
                <p>${ticket.admin_instruction}</p>
                
                <div class="feedback-section" style="margin-top: 1rem;">
                    <p><strong>Did this instruction work?</strong></p>
                    <div class="feedback-buttons">
                        <button class="btn-success" onclick="verifyInstruction(true)">Yes, issue resolved</button>
                        <button class="btn-danger" onclick="verifyInstruction(false)">No, did not work</button>
                    </div>
                </div>
            </div>
        `;
    }

    html += `</div>`;
    ticketArea.innerHTML = html;
}

async function submitFeedback(worked) {
    if (!currentTicketId) return;
    try {
        const res = await fetch(`/api/tickets/${currentTicketId}/feedback`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ worked: worked })
        });
        const ticket = await res.json();
        renderTicket(ticket);
    } catch (e) {
        alert("Failed to submit feedback");
    }
}

async function verifyInstruction(worked) {
    if (!currentTicketId) return;
    try {
        const res = await fetch(`/api/tickets/${currentTicketId}/verify`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ worked: worked })
        });
        const ticket = await res.json();
        renderTicket(ticket);
    } catch (e) {
        alert("Failed to verify instruction");
    }
}

function startPolling() {
    clearInterval(pollInterval);
    pollInterval = setInterval(async () => {
        if (!currentTicketId) return;
        try {
            const res = await fetch(`/api/tickets/${currentTicketId}`);
            const ticket = await res.json();
            if (ticket.status !== 'ESCALATED_IT') {
                clearInterval(pollInterval);
                renderTicket(ticket);
            }
        } catch (e) {
            console.error("Polling error", e);
        }
    }, 3000);
}
