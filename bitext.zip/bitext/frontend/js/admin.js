const ticketList = document.getElementById('ticketList');

function getStatusLabel(status) {
    const map = {
        'PENDING_FEEDBACK': 'Pending Feedback',
        'AUTO_RESOLVED': 'Auto-Resolved',
        'ESCALATED_IT': 'Escalated to IT',
        'PENDING_USER_VERIFICATION': 'Pending Verification',
        'CLOSED_RESOLVED': 'Closed'
    };
    return map[status] || status;
}

async function fetchTickets() {
    try {
        const res = await fetch('/api/admin/tickets');
        const tickets = await res.json();
        
        if (tickets.length === 0) {
            ticketList.innerHTML = '<tr><td colspan="4" style="text-align: center;">No tickets found.</td></tr>';
            return;
        }

        // Sort: newest first or escalated first. For simplicity, just reverse so newest is top if ordered by insertion
        tickets.reverse();

        let html = '';
        tickets.forEach(t => {
            let actionHtml = '';
            
            if (t.status === 'ESCALATED_IT') {
                actionHtml = `
                    <div class="admin-action-box">
                        <input type="text" id="inst-${t.id}" placeholder="Provide instructions...">
                        <button class="btn-primary" style="padding: 0.5rem 1rem;" onclick="sendInstruction('${t.id}')">Send</button>
                    </div>
                `;
            } else if (t.status === 'PENDING_USER_VERIFICATION') {
                actionHtml = `<em style="color:var(--text-light)">Waiting for user...</em>`;
            } else {
                actionHtml = `<span style="color:var(--text-light)">None</span>`;
            }

            html += `
                <tr>
                    <td style="font-family: monospace; font-size: 0.85rem;" title="${t.id}">${t.id.substring(0,8)}...</td>
                    <td><div style="max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${t.user_query}">${t.user_query}</div></td>
                    <td><span class="ticket-status status-${t.status}" style="margin:0">${getStatusLabel(t.status)}</span></td>
                    <td>${actionHtml}</td>
                </tr>
            `;
        });
        ticketList.innerHTML = html;
    } catch (e) {
        ticketList.innerHTML = '<tr><td colspan="4" style="color: red; text-align: center;">Failed to load tickets.</td></tr>';
    }
}

async function sendInstruction(ticketId) {
    const input = document.getElementById(`inst-${ticketId}`);
    const instruction = input.value.trim();
    
    if (!instruction) {
        alert("Please provide an instruction.");
        return;
    }
    
    try {
        await fetch(`/api/admin/tickets/${ticketId}/instruction`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ instruction: instruction })
        });
        fetchTickets(); // Refresh
    } catch (e) {
        alert("Failed to send instruction.");
    }
}

// Initial fetch and poll every 5 seconds
fetchTickets();
setInterval(fetchTickets, 5000);
