"""Autocomplete functionality based on the Bitext dataset."""

import csv
from pathlib import Path
import structlog

log = structlog.get_logger()

class AutocompleteEngine:
    def __init__(self):
        self.suggestions = []
        self._load_data()

    def _load_data(self):
        # Look for the dataset
        base_dir = Path(__file__).parent.parent.parent
        csv_file = base_dir / "Bitext_Sample_Customer_Support_Training_Dataset_27K_responses-v11" / "Bitext_Sample_Customer_Support_Training_Dataset_27K_responses-v11.csv"
        
        if not csv_file.exists():
            csv_file = base_dir / "Bitext_Sample_Customer_Support_Training_Dataset_27K_responses-v11" / "customer-support-agents" / "data" / "Bitext_Sample_Customer_Support_Training_Dataset_27K_responses-v11.csv"

        if not csv_file.exists():
            log.warning("autocomplete_data_not_found", path=str(csv_file))
            return

        unique_instructions = set()
        try:
            with open(csv_file, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    instruction = row.get('instruction', '').strip()
                    if instruction:
                        unique_instructions.add(instruction)
            
            self.suggestions = sorted(list(unique_instructions))
            log.info("autocomplete_data_loaded", count=len(self.suggestions))
        except Exception as e:
            log.error("autocomplete_load_failed", error=str(e))

    def get_suggestions(self, query: str, limit: int = 5) -> list[str]:
        if not query:
            return []
        
        query_lower = query.lower()
        results = []
        
        # Simple prefix or substring match
        for item in self.suggestions:
            if query_lower in item.lower():
                results.append(item)
                if len(results) >= limit:
                    break
        
        return results

# Global singleton
engine = AutocompleteEngine()

def get_suggestions(query: str, limit: int = 5):
    return engine.get_suggestions(query, limit)
