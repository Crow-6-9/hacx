"""Configuration for Backend."""

import os
from dotenv import load_dotenv

# Load from ../../.env to share the env variables
load_dotenv(os.path.join(os.path.dirname(__file__), "..", "..", ".env"))

# Fine-tuned model endpoint (Azure Model-as-a-Service endpoint)
MISTRAL_FT_ENDPOINT = os.getenv("AZURE_FT_ENDPOINT_URL")

# Clean up endpoint URL - remove /v1/completions if present
if MISTRAL_FT_ENDPOINT:
    if "/v1/completions" in MISTRAL_FT_ENDPOINT:
        MISTRAL_FT_ENDPOINT = MISTRAL_FT_ENDPOINT.replace("/v1/completions", "")
    if "/v1" in MISTRAL_FT_ENDPOINT:
        MISTRAL_FT_ENDPOINT = MISTRAL_FT_ENDPOINT.replace("/v1", "")
    # Ensure endpoint has trailing slash
    if not MISTRAL_FT_ENDPOINT.endswith("/"):
        MISTRAL_FT_ENDPOINT += "/"

# API key for the fine-tuned model
MISTRAL_FT_API_KEY = os.getenv("AZURE_FT_API_KEY")

# Model deployment name (as configured in Azure OpenAI)
MISTRAL_FT_MODEL_NAME = os.getenv("AZURE_FT_MODEL_NAME", "Ministral-3B-merlin")

# Inference settings
MAX_TOKENS = 1024
TEMPERATURE = 0.7
TOP_P = 0.9

# Server settings
HOST = "127.0.0.1"
PORT = 8000
