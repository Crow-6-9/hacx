"""FastAPI app for decoupled ITSM ticketing logic."""

import logging
import os
import uuid
from typing import Dict, Any, List
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from client import MistralFTClient
from config import HOST, PORT
import autocomplete

# Configure logging
LOG_DIR = Path(__file__).parent / "logs"
LOG_DIR.mkdir(exist_ok=True)
LOG_FILE = LOG_DIR / "app.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("bitext_backend")
logger.info("Application starting up. Log file configured.")

app = FastAPI(
    title="Bitext ITSM Backend",
    description="Backend API for Mistral-powered ITSM ticket triage and management."
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize Mistral Client
try:
    mistral_client = MistralFTClient()
    logger.info("Mistral client initialized.")
except Exception as e:
    logger.error(f"Failed to initialize Mistral client: {e}")
    mistral_client = None

# In-memory database for tickets
# Schema:
# {
#   "id": uuid,
#   "user_query": str,
#   "model_response": str,
#   "status": str (PENDING_FEEDBACK | AUTO_RESOLVED | ESCALATED_IT | PENDING_USER_VERIFICATION | CLOSED_RESOLVED),
#   "admin_instruction": str (optional),
#   "created_at": timestamp (string for simplicity)
# }
tickets_db: Dict[str, Dict[str, Any]] = {}

# Pydantic Models
class TicketCreateRequest(BaseModel):
    query: str
    system_prompt: str = "You are an expert customer support specialist. Provide clear, actionable solutions to customer issues."
    temperature: float = 0.7

class TicketFeedbackRequest(BaseModel):
    worked: bool

class AdminInstructionRequest(BaseModel):
    instruction: str

@app.get("/api/autocomplete")
def get_autocomplete(q: str = ""):
    """Returns autocomplete suggestions for the user query."""
    suggestions = autocomplete.get_suggestions(q, limit=5)
    return {"suggestions": suggestions}

@app.post("/api/tickets")
def create_ticket(request: TicketCreateRequest):
    """Creates a new ticket by passing the query to the Mistral model."""
    logger.info(f"Creating new ticket for query: {request.query}")
    
    if not mistral_client:
        logger.warning("Mistral client not configured, using mock response for testing.")
        result = {
            "status": "success",
            "reply": "This is a mocked response from the AI. If this doesn't resolve your issue, please click 'No' to escalate to IT."
        }
    else:
        result = mistral_client.infer(
            system_prompt=request.system_prompt,
            user_message=request.query,
            temperature=request.temperature
        )
    
    if result["status"] == "error":
        logger.error(f"Inference failed: {result.get('error')}")
        raise HTTPException(status_code=500, detail="Model inference failed.")
        
    ticket_id = str(uuid.uuid4())
    
    ticket = {
        "id": ticket_id,
        "user_query": request.query,
        "model_response": result["reply"],
        "status": "PENDING_FEEDBACK",
        "admin_instruction": None
    }
    
    tickets_db[ticket_id] = ticket
    logger.info(f"Ticket created: {ticket_id}")
    
    return ticket

@app.get("/api/tickets/{ticket_id}")
def get_ticket(ticket_id: str):
    """Retrieve a specific ticket."""
    if ticket_id not in tickets_db:
        raise HTTPException(status_code=404, detail="Ticket not found")
    return tickets_db[ticket_id]

@app.post("/api/tickets/{ticket_id}/feedback")
def provide_feedback(ticket_id: str, feedback: TicketFeedbackRequest):
    """User provides initial feedback on whether the model's response worked."""
    if ticket_id not in tickets_db:
        raise HTTPException(status_code=404, detail="Ticket not found")
        
    ticket = tickets_db[ticket_id]
    if ticket["status"] != "PENDING_FEEDBACK":
        raise HTTPException(status_code=400, detail="Feedback already provided or ticket not in PENDING state")
        
    if feedback.worked:
        ticket["status"] = "AUTO_RESOLVED"
        logger.info(f"Ticket {ticket_id} auto-resolved.")
    else:
        ticket["status"] = "ESCALATED_IT"
        logger.info(f"Ticket {ticket_id} escalated to IT.")
        
    return ticket

@app.post("/api/tickets/{ticket_id}/verify")
def verify_admin_instruction(ticket_id: str, feedback: TicketFeedbackRequest):
    """User verifies if the IT admin's instruction worked."""
    if ticket_id not in tickets_db:
        raise HTTPException(status_code=404, detail="Ticket not found")
        
    ticket = tickets_db[ticket_id]
    if ticket["status"] != "PENDING_USER_VERIFICATION":
        raise HTTPException(status_code=400, detail="Ticket not pending user verification")
        
    if feedback.worked:
        ticket["status"] = "CLOSED_RESOLVED"
        logger.info(f"Ticket {ticket_id} resolved by IT.")
    else:
        ticket["status"] = "ESCALATED_IT"
        logger.info(f"Ticket {ticket_id} re-escalated to IT.")
        
    return ticket

@app.get("/api/admin/tickets")
def get_all_tickets():
    """Retrieve all tickets for the admin dashboard."""
    # Convert dict to list
    return list(tickets_db.values())

@app.post("/api/admin/tickets/{ticket_id}/instruction")
def add_admin_instruction(ticket_id: str, req: AdminInstructionRequest):
    """Admin provides an instruction for an escalated ticket."""
    if ticket_id not in tickets_db:
        raise HTTPException(status_code=404, detail="Ticket not found")
        
    ticket = tickets_db[ticket_id]
    if ticket["status"] != "ESCALATED_IT":
        raise HTTPException(status_code=400, detail="Ticket is not escalated to IT")
        
    ticket["admin_instruction"] = req.instruction
    ticket["status"] = "PENDING_USER_VERIFICATION"
    logger.info(f"Admin provided instruction for ticket {ticket_id}")
    
    return ticket

# Serve static frontend files
FRONTEND_DIR = Path(__file__).parent.parent / "frontend"
if FRONTEND_DIR.exists():
    app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="frontend")
else:
    logger.warning(f"Frontend directory not found at {FRONTEND_DIR}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host=HOST, port=PORT, reload=True)
