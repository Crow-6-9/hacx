"""Mistral Fine-Tuned Model Inference Client."""

import structlog
import requests
from config import MISTRAL_FT_ENDPOINT, MISTRAL_FT_API_KEY, MISTRAL_FT_MODEL_NAME, MAX_TOKENS, TEMPERATURE

log = structlog.get_logger()

class MistralFTClient:
    """Client for interacting with the fine-tuned Mistral model via Azure MaaS endpoint."""
    
    def __init__(self):
        """Initialize the client for Azure Model-as-a-Service endpoint."""
        if not MISTRAL_FT_API_KEY:
            raise ValueError("AZURE_FT_API_KEY environment variable must be set")
        if not MISTRAL_FT_ENDPOINT:
            raise ValueError("AZURE_FT_ENDPOINT_URL environment variable must be set")
        
        self.endpoint = MISTRAL_FT_ENDPOINT
        self.api_key = MISTRAL_FT_API_KEY
        self.model_name = MISTRAL_FT_MODEL_NAME
        
        # Construct the full chat completions endpoint URL
        self.chat_endpoint = f"{self.endpoint.rstrip('/')}/v1/chat/completions"
        
        log.info(
            "mistral_ft_client_initialized",
            endpoint=self.endpoint,
            model=self.model_name,
            chat_endpoint=self.chat_endpoint
        )
    
    def infer(self, system_prompt: str, user_message: str, temperature: float = TEMPERATURE) -> dict:
        """
        Send a request to the fine-tuned model and get a response.
        """
        try:
            log.info(
                "mistral_ft_request_start",
                model=self.model_name,
                system_prompt_len=len(system_prompt),
                user_message_len=len(user_message),
            )
            
            # Prepare the request payload
            payload = {
                "model": self.model_name,
                "max_tokens": MAX_TOKENS,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_message},
                ],
                "temperature": temperature,
            }
            
            # Prepare headers with authorization
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            }
            
            # Make HTTP POST request to the endpoint
            response = requests.post(
                self.chat_endpoint,
                json=payload,
                headers=headers,
                timeout=60
            )
            response.raise_for_status()
            
            # Parse the response
            data = response.json()
            reply = data["choices"][0]["message"]["content"]
            
            # Extract token counts if available
            usage = data.get("usage", {})
            prompt_tokens = usage.get("prompt_tokens", 0)
            completion_tokens = usage.get("completion_tokens", 0)
            total_tokens = usage.get("total_tokens", prompt_tokens + completion_tokens)
            
            result = {
                "reply": reply,
                "tokens_used": {
                    "prompt": prompt_tokens,
                    "completion": completion_tokens,
                    "total": total_tokens,
                },
                "model": self.model_name,
                "temperature": temperature,
                "status": "success",
            }
            
            log.info(
                "mistral_ft_response_success",
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
            )
            
            return result
        
        except requests.exceptions.RequestException as e:
            log.error("mistral_ft_inference_failed", error=str(e), exc_info=True)
            return {
                "reply": None,
                "error": str(e),
                "status": "error",
                "model": self.model_name,
            }
        except Exception as e:
            log.error("mistral_ft_inference_failed", error=str(e), exc_info=True)
            return {
                "reply": None,
                "error": str(e),
                "status": "error",
                "model": self.model_name,
            }
    
    def test_connection(self) -> bool:
        """Test if the fine-tuned model endpoint is reachable."""
        try:
            log.info("mistral_ft_testing_connection")
            result = self.infer(
                system_prompt="You are a helpful assistant.",
                user_message="Hello, can you confirm the connection is working?",
            )
            if result["status"] == "success":
                log.info("mistral_ft_connection_test_passed")
                return True
            else:
                log.warning("mistral_ft_connection_test_failed", error=result.get("error"))
                return False
        except Exception as e:
            log.error("mistral_ft_connection_test_exception", error=str(e))
            return False
